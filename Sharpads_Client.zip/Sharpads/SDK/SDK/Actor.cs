﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sharpads.SDK.SDK
{
    public class Actor : SDKObject
    {
        public Actor(string addr) : base(addr) { }
    }
}
