﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sharpads.SDK
{
    public class Statics
    {
        public static string Knockback_X = "Minecraft.Windows.exe+1941622"; //v1.16.221
        public static string Knockback_Y = "Minecraft.Windows.exe+194162B"; //v1.16.221
        public static string Knockback_Z = "Minecraft.Windows.exe+1941634"; //v1.16.221
        public static string GameFPS = "Minecraft.Windows.exe+394DB6C"; //v1.16.221
        public static string reach = "Minecraft.Windows.exe+2FED138"; //v1.16.221
    }
}
