﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sharpads.SDK
{
    public class Pointers
    {
        public static string gamemodeSpoof = "Minecraft.Windows.exe+03CDD128,0,18,88,B68,0,BA4"; //v1.16.221
        public static string chatString = "Minecraft.Windows.exe+03CCB7A0,0,4D0,2A0,78,8"; //v1.16.221
        public static string rakNet = "Minecraft.Windows.exe+03CD3008,0,178,8,1F0,3A0,"; //v1.16.221
        public static string hitting = "Minecraft.Windows.exe+03CCB7A0,0,4E8,288,8,50"; //v1.16.221
        public static string localPlayer = "Minecraft.Windows.exe+03CDE520,38,50,140,"; //v1.16.221
        public static string floatOption = "Minecraft.Windows.exe+03948840,18,130,18"; //v1.16.221
        public static string time = "Minecraft.Windows.exe+0360A218,1B8,18,0,1F8,5D8"; //v1.16.221
        public static string sprinting = "Minecraft.Windows.exe+0360A218,40,60,E8,5C"; //v1.16.221
        public static string debug = "Minecraft.Windows.exe+03904580,"; //v1.16.221

        public static string a = ""; //v1.16.221
    }
}
