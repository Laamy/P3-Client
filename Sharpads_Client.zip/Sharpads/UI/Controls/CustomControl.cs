﻿using System.Drawing;

namespace Sharpads.UI.Controls
{
    class CustomControl
    {
        public virtual void draw(Graphics e, string font, Point Location, string text, float textSize, Brush color)
        {
        }
    }
}
