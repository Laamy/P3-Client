﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sharpads
{
    class Cache
    {
        public static string staffList = @"Flyinggotters
May May Love15
ItzMeKenji
FourthFlames1234
ImRieSky
RIA
SupposedJoker420
Rimaaax
M3 TenseUnicorn
yTzBlackkoutz
xZolpha
XxStonzeyXx
xXAmylee12
XtReMe9x
xSTEAM12x
WaxAhmed303
Vulth1428
vMoonliight
v Ruee v
UnrealSavage94
Todoe56
ThisRedPanda74
TheEpicMiner
Alumae (bans as db)
ArguableTerror4
AsharaFoS
Brandovalencia
BroughtRapier55
ChaseCi
CooperCaspian
Crytek I Raven
CyanCreeperPlayz
Deathstrike1016
Delraylau
Dewsek
Didebop
Doggo Ascends
EliteKing716
EmeraldDragonYT
Fishy255
Flora7640
FlyingZombieGod
FofahPants819
Fractions BR
FxckSmiles
HazelCarton3487
HeyitzAva
HiddenWolves
Iblamekoda
iDavid5xD
iiKfcDerPii
IrishPotatoo
iTzN3xdr0
ItzSear5499
Itzsmith
JahirMC10
Josewowgame2888
Killshunter1676
Kyletthuis
Lenchagame
LexiBxxxly
Libbyfxrd
LifeboatNetwork
Llbino
Lunarrixxq
MarieSoliel
Mayzhouse25
MemeMan2099
MightyPieAJR
MonicaLandiii
Necryii
NeonVampire
NeutralStatue560
Nexdro
OpTic SpiderAnt
Pewds the GOAT
Pikachueevee280
Pineangoo
Pius1212
PopGoesTheNoobs
ProZeni
Qcjb
RealR86
RoomyCartoon84
RubenCraftReal
ShadowFoxDragon
Shanndon01
SharpAmI
ShavindaN
SigningComet714
SillyZoo
Silvermantis77
SilverStream688
Simartar
SirWill ll
SS Valnessa
Supitscoco";
    }
}
